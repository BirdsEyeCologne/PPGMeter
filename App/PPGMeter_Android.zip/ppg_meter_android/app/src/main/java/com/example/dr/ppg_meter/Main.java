package com.example.dr.ppg_meter;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.icu.util.Calendar;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.lang.Thread;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class Main extends AppCompatActivity {

    private final static int REQUEST_CODE_ASK_PERMISSIONS = 1;

    private static final String[] REQUIRED_SDK_PERMISSIONS = new String[] {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

    private UpdateHandler m_updateHandler;
    private BTCom m_btCom;
    private GPSLoc m_gps;
    private ViewPager m_pager;
    private ViewAdapter m_adapter;


    public final class Plot {
        public static final int NONE = 1;
        public static final int ALL = 2;
        public static final int BT_ERR = 3;
        public static final int BT_SCAN = 4;
        private Plot() {}
    }

    // ******************************************************************
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        // Get permissions for GPS location.
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
        }

        // Sets up swipe view with 3 items, MainView (mv), LocationView (lv) and MiscView (miv)
        m_pager = findViewById(R.id.pager);
        m_adapter = new ViewAdapter(getSupportFragmentManager());
        m_pager.setAdapter(m_adapter);


        // Handles the received data from BTCom thread.
        m_updateHandler = new UpdateHandler(this);

        // GPS location.
        m_gps = new GPSLoc(this);

        // Start BTCom thread.
        m_btCom = new BTCom(m_updateHandler);
        Thread thread = new Thread(m_btCom);
        thread.start();
    }

    // ******************************************************************
    @Override
    protected void onDestroy() {
        super.onDestroy();
        m_btCom.stop_run();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // ******************************************************************
    public void onNewBTData(float lat, float lon, short spd, short alt){

        Calendar calendar = Calendar.getInstance();
        ByteBuffer buffer = ByteBuffer.allocate(18);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put((byte)0xAA);

        buffer.putFloat(lat);
        buffer.putFloat(lon);
        buffer.putShort(spd);
        buffer.putShort(alt);

        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1;
        int year = calendar.get(Calendar.YEAR) - 2000;
        int min = calendar.get(Calendar.MINUTE);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);

        buffer.put((byte)(min & 0xFF));
        buffer.put((byte)(hour & 0xFF));
        buffer.put((byte)(day & 0xFF));
        buffer.put((byte)(month & 0xFF));
        buffer.put((byte)(year & 0xFF));

        try{
            m_btCom.send_data(buffer.array());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // ******************************************************************
    protected void checkPermissions() {
        final List<String> missingPermissions = new ArrayList<String>();
        // check all required dynamic permissions
        for (final String permission : REQUIRED_SDK_PERMISSIONS) {
            final int result = ContextCompat.checkSelfPermission(this, permission);
            if (result != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }
        if (!missingPermissions.isEmpty()) {
            // request all missing permissions
            final String[] permissions = missingPermissions
                    .toArray(new String[missingPermissions.size()]);
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            final int[] grantResults = new int[REQUIRED_SDK_PERMISSIONS.length];
            Arrays.fill(grantResults, PackageManager.PERMISSION_GRANTED);
            onRequestPermissionsResult(REQUEST_CODE_ASK_PERMISSIONS, REQUIRED_SDK_PERMISSIONS,
                    grantResults);
        }
    }

    // ******************************************************************
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                for (int index = permissions.length - 1; index >= 0; --index) {
                    if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {
                        this.finish();
                        return;
                    }
                }
                break;
        }
    }

    // ******************************************************************
    private class UpdateHandler extends Handler {


        private int m_toggle = 0;
        private final WeakReference<Activity> m_activity;

        private TextView rpm_mv_text;
        private TextView temp1_mv_text;
        //private TextView temp2_mv_text;
        private TextView spd_mv_text;
        private TextView alt_mv_text;

        private TextView lat_lv_text;
        private TextView lon_lv_text;
        private TextView alt_lv_text;
        private TextView spd_lv_text;

        private TextView temp3_miv_text;
        private TextView pressure_miv_text;
        private TextView hour_miv_text;


        // *****************************************************************
        public UpdateHandler(Activity activity) {

            m_activity = new WeakReference<>(activity);

        }

        // *****************************************************************
        @Override
        public synchronized void handleMessage(Message msg) {

            Activity activity = m_activity.get();

            if (activity != null) {     // get views from weak activity

                rpm_mv_text = activity.findViewById(R.id.rpm_mv_text);
                temp1_mv_text = activity.findViewById(R.id.temp1_mv_text);
                //temp2_mv_text = activity.findViewById(R.id.temp2_mv_text);
                spd_mv_text = activity.findViewById(R.id.spd_mv_text);
                alt_mv_text = activity.findViewById(R.id.alt_mv_text);

                lat_lv_text = activity.findViewById(R.id.lat_lv_text);
                lon_lv_text = activity.findViewById(R.id.lon_lv_text);
                alt_lv_text = activity.findViewById(R.id.alt_lv_text);
                spd_lv_text = activity.findViewById(R.id.spd_lv_text);

                temp3_miv_text = activity.findViewById(R.id.temp3_miv_text);
                pressure_miv_text = activity.findViewById(R.id.pressure_miv_text);
                hour_miv_text = activity.findViewById(R.id.hour_miv_text);
            }


            switch (msg.what) {

                case Plot.ALL:

                    // prepare gps stuff to be transmitted back to uc.
                    float lat = 0;
                    float lon = 0;
                    short spd = 0;
                    short alt = 0;

                    Location loc = m_gps.get_location();

                    if (loc != null) {
                        lat = (float) loc.getLatitude();
                        lon = (float)loc.getLongitude();
                        spd = (short)loc.getSpeed();
                        spd *= 3.6;
                        alt = (short)loc.getAltitude();
                    }

                    // send data back to uc
                    onNewBTData(lat, lon, spd, alt);


                    // stuff to be visualized, sent by uc.
                    String[] values = (String[]) msg.obj;

                    if(values.length != 6){
                        break;
                    }


                    if(m_pager.getCurrentItem() == 0) {

                        if (m_toggle++ % 2 == 0) {
                            rpm_mv_text.setText("RPM: " + values[0]);
                            rpm_mv_text.invalidate();
                        } else {
                            rpm_mv_text.setText("RPM: " + values[0] + " .");
                            rpm_mv_text.invalidate();
                        }

                        temp1_mv_text.setText("CHT: " + values[1] + " °C");
                        temp1_mv_text.invalidate();

                        //temp2_mv_text.setText("EGT: " + values[2] + " °C");
                        //temp2_mv_text.invalidate();

                        spd_mv_text.setText("SPD: " + String.valueOf(spd) + " km/h");
                        spd_mv_text.invalidate();


                        alt_mv_text.setText("ALT: " + String.valueOf(alt) + " m");
                        alt_mv_text.invalidate();
                    }

                    if(m_pager.getCurrentItem() == 1) {

                        lat_lv_text.setText("LAT: " + String.format("%.6f", lat));
                        lat_lv_text.invalidate();

                        lon_lv_text.setText("LON: " + String.format("%.6f", lon));
                        lon_lv_text.invalidate();

                        alt_lv_text.setText("ALT: " + String.valueOf(alt) + " m");
                        alt_lv_text.invalidate();

                        spd_lv_text.setText("SPD: " + String.valueOf((int) spd) + " km/h");
                        spd_lv_text.invalidate();
                    }

                    if(m_pager.getCurrentItem() == 2) {

                        temp3_miv_text.setText("AMB: " + values[3] + " °C");
                        temp3_miv_text.invalidate();

                        pressure_miv_text.setText("PRES: " + values[4] + " mb");
                        pressure_miv_text.invalidate();

                        hour_miv_text.setText("RUN: " + values[5] + " h");
                        hour_miv_text.invalidate();
                    }

                    break;

                case Plot.BT_ERR:
                    if(m_pager.getCurrentItem() == 0) {
                       rpm_mv_text.setText("BT Error!!");
                       rpm_mv_text.invalidate();
                        temp1_mv_text.setText("");
                        temp1_mv_text.invalidate();
                        //temp2_mv_text.setText("");
                        //temp2_mv_text.invalidate();
                        spd_mv_text.setText("");
                        spd_mv_text.invalidate();
                        alt_mv_text.setText("");
                        alt_mv_text.invalidate();
                    }
                    if(m_pager.getCurrentItem() == 1) {
                        lat_lv_text.setText("BT Error!!");
                        lat_lv_text.invalidate();
                        lon_lv_text.setText("");
                        lon_lv_text.invalidate();
                        alt_lv_text.setText("");
                        alt_lv_text.invalidate();
                        spd_lv_text.setText("");
                        spd_lv_text.invalidate();
                    }
                    if(m_pager.getCurrentItem() == 2) {
                        temp3_miv_text.setText("BT Error!!");
                        temp3_miv_text.invalidate();
                        pressure_miv_text.setText("");
                        pressure_miv_text.invalidate();
                        hour_miv_text.setText("");
                        hour_miv_text.invalidate();
                    }
                    break;

                case Plot.BT_SCAN:
                    if(m_pager.getCurrentItem() == 0) {
                        rpm_mv_text.setText("BT Scan!");
                        rpm_mv_text.invalidate();
                        temp1_mv_text.setText("");
                        temp1_mv_text.invalidate();
                        //temp2_mv_text.setText("");
                        //temp2_mv_text.invalidate();
                        spd_mv_text.setText("");
                        spd_mv_text.invalidate();
                        alt_mv_text.setText("");
                        alt_mv_text.invalidate();
                    }
                    if(m_pager.getCurrentItem() == 1) {
                        lat_lv_text.setText("BT Scan!");
                        lat_lv_text.invalidate();
                        lon_lv_text.setText("");
                        lon_lv_text.invalidate();
                        alt_lv_text.setText("");
                        alt_lv_text.invalidate();
                        spd_lv_text.setText("");
                        spd_lv_text.invalidate();
                    }
                    if(m_pager.getCurrentItem() == 2) {
                        temp3_miv_text.setText("BT Scan!");
                        temp3_miv_text.invalidate();
                        pressure_miv_text.setText("");
                        pressure_miv_text.invalidate();
                        hour_miv_text.setText("");
                        hour_miv_text.invalidate();
                    }
                    break;

             }


            }


    }

}

