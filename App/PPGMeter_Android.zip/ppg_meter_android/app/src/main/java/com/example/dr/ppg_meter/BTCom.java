package com.example.dr.ppg_meter;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.icu.util.Calendar;
import android.os.Handler;
import android.os.Message;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

// **********************************************************************************************************************************
public class BTCom implements Runnable {

    private static final List<String> DEVICE_NAMES = Arrays.asList(new String[]{"DR-PPGMS","HC-05"});

    private final static int TIMEOUT_CNT = 10;

    private Calendar m_calendar = Calendar.getInstance();

    private BluetoothSocket m_socket;
    private BluetoothAdapter m_adapter;
    private InputStream m_istream;
    private BufferedOutputStream m_ostream;
    private volatile int m_is_running;
    private int m_sleep;
    private enum FSM{SCAN, READ, SEND};
    private FSM m_state;
    private final Handler m_updateHandler;

    // ******************************************************************
    public BTCom(Handler updateHandler){
        m_updateHandler = updateHandler;
    }

    // ******************************************************************
    public void send_data(byte [] buffer){
        try {
            m_ostream.write(buffer);
            m_ostream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ******************************************************************
    @Override
    public void run() {

        m_state = FSM.SCAN;
        m_sleep = 300;
        m_is_running = 1;
        int timeout_cnt = 0;

        try {
            m_adapter = BluetoothAdapter.getDefaultAdapter();

            if (m_adapter == null) {
                String st = "BT Error!";
                Message.obtain(m_updateHandler, Main.Plot.BT_ERR, st).sendToTarget();
                m_is_running = 0;
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return;
        }


        byte[] buffer = new byte[17];

        while (m_is_running == 1) {

            // ***************************************************
            if (m_state == FSM.SCAN) {

                try {
                    String st = "BT Scan!";
                    Message.obtain(m_updateHandler, Main.Plot.BT_SCAN, st).sendToTarget();

                    Set<BluetoothDevice> pairedDevices = m_adapter.getBondedDevices();
                    Iterator<BluetoothDevice> iterator = pairedDevices.iterator();

                    while (iterator.hasNext()) {

                        BluetoothDevice device = iterator.next();

                        if (DEVICE_NAMES.contains(device.getName())) {
                            try{
                                m_socket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                                m_socket.connect();
                                m_istream = m_socket.getInputStream();
                                m_ostream = new BufferedOutputStream(m_socket.getOutputStream());
                                m_state = FSM.READ; // change to SEND for debug values.
                                break;
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    m_sleep = 1000;
                }
            }

            // ***************************************************
            if (m_state == FSM.READ) {

                if(timeout_cnt > TIMEOUT_CNT){
                    m_state = FSM.SCAN;
                    timeout_cnt = 0;
                    continue;
                }

                int avail = 0;

                // read data to buffer.
                try{
                    avail = m_istream.available();

                    if(avail < 17 && avail > 0){
                        m_sleep = 100;
                    }else{
                        m_sleep = 300;
                    }

                    if(avail == 17){
                        m_istream.read(buffer, 0, avail);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    m_sleep = 1000;
                    m_state = FSM.SCAN;
                }

                // handle data on buffer and send date time back to uc.
                if (avail == 17 && (buffer[0] & 0xFF) == 0xAD) {

                    timeout_cnt = 0;

                    int temp1 = 0;
                    temp1 |= buffer[2] & 0xFF;
                    temp1 <<= 8;
                    temp1 |= buffer[1] & 0xFF;

                    int temp2 = 0;
                    temp2 |= buffer[4] & 0xFF;
                    temp2 <<= 8;
                    temp2 |= buffer[3] & 0xFF;

                    int temp3 = 0;
                    temp3 |= buffer[6] & 0xFF;
                    temp3 <<= 8;
                    temp3 |= buffer[5] & 0xFF;

                    int press = 0;
                    press |= buffer[10] & 0xFF;
                    press <<= 8;
                    press |= buffer[9] & 0xFF;
                    press <<= 8;
                    press |= buffer[8] & 0xFF;
                    press <<= 8;
                    press |= buffer[7] & 0xFF;

                    float mb = press;
                    mb /= 100.0;

                    int rpm = 0;
                    rpm |= buffer[12] & 0xFF;
                    rpm <<= 8;
                    rpm |= buffer[11] & 0xFF;

                    int hour = 0;
                    hour |= buffer[16] & 0xFF;
                    hour <<= 8;
                    hour |= buffer[15] & 0xFF;
                    hour <<= 8;
                    hour |= buffer[14] & 0xFF;
                    hour <<= 8;
                    hour |= buffer[13] & 0xFF;

                    float h = hour;
                    h /= 3600.0f;


                    String [] str_arr = {
                            String.valueOf(rpm),
                            String.valueOf(temp1),
                            String.valueOf(temp2),
                            String.valueOf(temp3),
                            String.valueOf(mb),
                            String.format("%.2f", h)
                    };

                    Message.obtain(m_updateHandler, Main.Plot.ALL, str_arr).sendToTarget();
                }

            }

            try {
                Thread.sleep(m_sleep);
                timeout_cnt++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        try {
            m_socket.close();
            m_istream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    // ******************************************************************
    public void stop_run (){
        m_is_running = 0;
    }


    // ******************************************************************
    private void send(double lat, double lon, int spd, int alt){

        ByteBuffer buf = ByteBuffer.allocate(25);
        buf.order(ByteOrder.LITTLE_ENDIAN);

        buf.put((byte)0xAA);

        buf.putDouble(lat);
        buf.putDouble(lon);
        buf.putInt(spd);
        buf.putInt(alt);

        send_data(buf.array());
    }
}
