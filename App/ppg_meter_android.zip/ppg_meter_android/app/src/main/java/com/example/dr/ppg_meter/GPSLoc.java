package com.example.dr.ppg_meter;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;


public class GPSLoc implements LocationListener {

    private LocationManager m_locationManager;

    private static final int m_interval_ms = 1000;
    private static final int m_min_dist = 10;

    private Location m_location = null;

    // ******************************************************************
    public GPSLoc(Activity main) {

        m_locationManager = (LocationManager) main.getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(main, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(main, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        m_locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, m_interval_ms, m_min_dist, this);
        m_location = m_locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    }


    // ******************************************************************
    public Location get_location(){
        return m_location;
    }

    // ******************************************************************
    @Override
    public void onLocationChanged(Location location) {
        m_location = location;
    }

    // ******************************************************************
    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {}

    // ******************************************************************
    @Override
    public void onProviderEnabled(String s) {}

    // ******************************************************************
    @Override
    public void onProviderDisabled(String s) {}
}
