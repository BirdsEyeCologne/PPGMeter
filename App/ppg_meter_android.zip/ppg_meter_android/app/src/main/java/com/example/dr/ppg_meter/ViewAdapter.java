package com.example.dr.ppg_meter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewAdapter extends FragmentPagerAdapter {

    static final MainView main_view = new MainView();
    static final LocationView loc_view = new LocationView();
    static final MiscView msc_view = new MiscView();

    public ViewAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {

        Fragment view = null;

        switch (i) {
            case 0:
                view = main_view;
            break;

            case 1:
                view = loc_view;
            break;

            case 2:
                view = msc_view;
            break;
        }

        return view;
    }

    @Override
    public int getCount() {
        return 3;
    }
}
